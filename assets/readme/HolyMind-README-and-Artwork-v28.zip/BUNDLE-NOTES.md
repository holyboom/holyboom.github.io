# HolyMind — README & artwork

Keep README.md and assets/readme at the same relative paths. This is the README/artwork package, not the complete website. Open qa/fieldnotes-v28.html for a browser preview. Runtime and historical-source references belong to the full repository: https://github.com/holyboom/holyboom.github.io. No font binaries or private documents are included.

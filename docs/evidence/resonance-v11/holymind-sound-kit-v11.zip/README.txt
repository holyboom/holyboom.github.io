HolyMind original sonic identity.
Run: node scripts/build-sounds.cjs
No dependencies required. Read assets/audio/README.md for provenance.
Fourteen synthesized DSP cues, not real recordings or generative-audio model output.
